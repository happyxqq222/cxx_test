/**
 * @brief 字符串数组
 */
#pragma once

#include <string>
#include <vector>

namespace wheels
{
typedef std::vector< std::string>  ary_str;
typedef ary_str aryStr_t;
typedef ary_str ArrayString;
}
