#ifndef __TRIBOOL_HPP__
#define __TRIBOOL_HPP__

typedef char tribool_t;
static const tribool_t  triTrue = 1;
static const tribool_t  triFalse = -1;
static const tribool_t  triReady = 0;
#endif
